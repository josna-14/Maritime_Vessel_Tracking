import React, { useEffect, useState, useRef } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import { fetchLiveVessels } from "../api/api";
import Loader from "./Loader";

/* ===================================================
   AnimatedMarker – smooth movement between updates
=================================================== */
function AnimatedMarker({ position, icon, children }) {
  const markerRef = useRef(null);
  const previousPosition = useRef(position);

  useEffect(() => {
    if (!markerRef.current) return;

    const marker = markerRef.current;
    const from = L.latLng(previousPosition.current);
    const to = L.latLng(position);

    const duration = 1000; // 1 second smooth animation
    const start = performance.now();

    function animate(time) {
      const progress = Math.min((time - start) / duration, 1);

      const lat = from.lat + (to.lat - from.lat) * progress;
      const lng = from.lng + (to.lng - from.lng) * progress;

      marker.setLatLng([lat, lng]);

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    }

    requestAnimationFrame(animate);
    previousPosition.current = position;
  }, [position]);

  return (
    <Marker ref={markerRef} position={position} icon={icon}>
      {children}
    </Marker>
  );
}

/* ===================================================
   Ship Arrow Icon (AIS-style directional arrow)
=================================================== */
const createShipIcon = (course = 0) =>
  L.divIcon({
    className: "ship-arrow-icon",
    html: `
      <svg width="26" height="26" viewBox="0 0 100 100"
        style="transform: rotate(${course}deg)">
        <polygon 
          points="50,5 95,95 50,75 5,95"
          fill="#1f3c88"
          stroke="white"
          stroke-width="6"
        />
      </svg>
    `,
    iconSize: [26, 26],
    iconAnchor: [13, 13],
  });

/* ===================================================
   Main Map Component
=================================================== */
export default function MapComponent({ center = [20, 0], zoom = 2 }) {
  const [vessels, setVessels] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    const loadVessels = async () => {
      try {
        const res = await fetchLiveVessels();

        // ✅ CORRECT: API returns { vessels: [...] }
        if (mounted && Array.isArray(res?.vessels)) {
          setVessels(res.vessels);
        }
      } catch (err) {
        console.error("Map fetch error:", err);
      } finally {
        setLoading(false);
      }
    };

    loadVessels();
    const interval = setInterval(loadVessels, 10000); // refresh every 10 sec

    return () => {
      mounted = false;
      clearInterval(interval);
    };
  }, []);

  if (loading) return <Loader />;

  return (
    <div
      className="map-wrapper"
      style={{ height: "80vh", borderRadius: 16, overflow: "hidden" }}
    >
      <MapContainer center={center} zoom={zoom} style={{ height: "100%" }}>
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution="© OpenStreetMap contributors"
        />

        {vessels.map((v) => {
          // ✅ Strong safety checks
          const lat = Number(v.last_position_lat);
          const lon = Number(v.last_position_lon);

         if (isNaN(lat) || isNaN(lon)) return null;


          return (
            <AnimatedMarker
              key={v.mmsi || v.imo_number}
              position={[v.last_position_lat, v.last_position_lon]}
              icon={createShipIcon(v.course || 0)}
            >
              <Popup>
                <b>{v.name || "Unknown Vessel"}</b>
                <br />
                IMO: {v.imo_number || "—"}
                <br />
                MMSI: {v.mmsi || "—"}
                <br />
                Speed: {v.speed || 0} kn
                <br />
                Updated:{" "}
                {v.last_update
                  ? new Date(v.last_update).toLocaleTimeString()
                  : "—"}
              </Popup>
            </AnimatedMarker>
          );
        })}
      </MapContainer>
    </div>
  );
}
