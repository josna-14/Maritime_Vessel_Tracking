import React, { useEffect, useState } from "react";
import axios from "axios";
import ShipCard from "../components/ShipCard";
import Loader from "../components/Loader";

import L from "leaflet";
// Import the ship icon from your assets folder
import shipIconImg from "../assests/ship-icon.png"; 

const shipIcon = new L.Icon({
  iconUrl: shipIconImg,
  iconSize: [30, 30],      // Adjust size as needed
  iconAnchor: [15, 15],    // Center the icon on the coordinates
  popupAnchor: [0, -15],   // Position the popup above the icon
});

export default function VesselSearch() {
  const [vessels, setVessels] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    setLoading(true);
    // Fetch data from your specific Django API
    axios.get("http://127.0.0.1:8000/api/vessels/")
      .then((res) => {
        // Correctly access the vessels array from the JSON response
        if (res.data && res.data.vessels) {
          setVessels(res.data.vessels);
        }
      })
      .catch(err => console.error("Search fetch error:", err))
      .finally(() => setLoading(false));
  }, []);

  const filtered = vessels.filter(ship => 
    ship.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ship.imo_number?.includes(searchTerm)
  );

  if (loading && vessels.length === 0) return <Loader />;

  return (
    <main className="page">
      <header className="page__header">
        <h1>Vessel Search</h1>
        <p>Tracking {filtered.length} vessels globally</p>
      </header>
      <section className="filters card">
        <input 
          type="text" 
          placeholder="Search by vessel name or IMO…" 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </section>
      <section className="grid grid--cards">
        {filtered.map((ship) => (
          // Use your dynamic ShipCard component
          <ShipCard key={ship.id} vessel={ship} />
        ))}
      </section>
    </main>
  );
}