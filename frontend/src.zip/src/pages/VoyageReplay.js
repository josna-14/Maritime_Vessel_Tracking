import React, { useEffect, useState, useRef } from "react";
import "./VoyageReplay.css";

export default function VoyageReplay() {
  const [tracks, setTracks] = useState([]);
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const timerRef = useRef(null);

  useEffect(() => {
    fetch("http://127.0.0.1:8000/api/voyage-track/1/")
      .then(res => res.json())
      .then(data => {
        setTracks(data);
        setIndex(0);
      });
  }, []);

  useEffect(() => {
    if (playing && tracks.length > 0) {
      timerRef.current = setInterval(() => {
        setIndex(prev => {
          if (prev < tracks.length - 1) return prev + 1;
          clearInterval(timerRef.current);
          return prev;
        });
      }, 1000);
    }
    return () => clearInterval(timerRef.current);
  }, [playing, tracks]);

  if (!tracks.length) return <p>Loading voyage data...</p>;

  const point = tracks[index];
  const progress = Math.round((index / (tracks.length - 1)) * 100);

  return (
    <main className="voyage-page">
      <h1>Voyage Replay</h1>
      <p className="subtitle">Replay vessel movement using AIS track data</p>

      <div className="card">
        <div className="controls">
          <button onClick={() => setPlaying(true)}>Play</button>
          <button onClick={() => setPlaying(false)}>Pause</button>
          <button onClick={() => { setIndex(0); setPlaying(false); }}>Reset</button>
        </div>

        <div className="progress">
          <div className="progress-bar" style={{ width: `${progress}%` }} />
          <span>{progress}%</span>
        </div>

        <div className="stats">
          <div><h4>Latitude</h4><p>{point.latitude}°</p></div>
          <div><h4>Longitude</h4><p>{point.longitude}°</p></div>
          <div><h4>Speed</h4><p>{point.speed} kn</p></div>
          <div><h4>Course</h4><p>{point.course}°</p></div>
          <div><h4>Time</h4><p>{new Date(point.timestamp).toLocaleString()}</p></div>
        </div>
      </div>
    </main>
  );
}
