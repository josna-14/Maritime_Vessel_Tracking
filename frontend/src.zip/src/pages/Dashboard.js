import React, { useEffect, useState } from "react";
import { fetchDashboardStats } from "../api/api";
import Loader from "../components/Loader";

export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadStats() {
      try {
        const data = await fetchDashboardStats();
        setStats(data);
      } catch (error) {
        console.error("Error loading dashboard stats:", error);
      } finally {
        setLoading(false);
      }
    }
    loadStats();
  }, []);

  const cards = [
    { title: "Total Vessels", value: stats?.totalVessels || "—", icon: "🚢" },
    { title: "Active Voyages", value: stats?.activeVoyages || "—", icon: "📊" },
    { title: "Ports Monitored", value: stats?.ports || "—", icon: "⚓" },
    { title: "Recent Events", value: stats?.events || "—", icon: "🔔" },
  ];

  if (loading) return <Loader />;

  return (
    <main className="page">
      <header className="page__header">
        <h1>Dashboard</h1>
        <p>Maritime Operations Overview</p>
      </header>

      <section className="grid grid--stats">
        {cards.map((card) => (
          <article key={card.title} className="card card--stat">
            <div className="card__icon">{card.icon}</div>
            <div>
              <p className="card__value">{card.value}</p>
              <p className="card__label">{card.title}</p>
            </div>
          </article>
        ))}
      </section>

      <section className="card table-card">
        <div className="card__header">
          <h2>Recent Voyages</h2>
          <p></p>
        </div>
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>Vessel</th>
                <th>Origin</th>
                <th>Destination</th>
                <th>Status</th>
                <th>Progress</th>
              </tr>
            </thead>
            <tbody>
              {Array.from({ length: 1 }).map((_, idx) => (
                <tr key={idx}>
                  <td>Vessel name</td>
                  <td>Origin</td>
                  <td>Destination</td>
                  <td>
                    <span className="status-chip">
                      Status
                    </span>
                  </td>
                  <td>
                    <div className="progress">
                      <div className="progress__bar" style={{ width: "0%" }} />
                      <span>0%</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </main>
  );
}
