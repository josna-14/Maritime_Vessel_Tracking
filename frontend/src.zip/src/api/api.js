
let mockVessels = [
  {
    id: 1,
    name: "MV Ocean Star",
    imo_number: "IMO1234567",
    last_position_lat: 1.3521,
    last_position_lon: 103.8198,
    speed: 18.5,
    course: 245,
    status: "In Transit",
    type: "Cargo",
  },
  {
    id: 2,
    name: "MV Atlantic Wave",
    imo_number: "IMO2345678",
    last_position_lat: 31.2304,
    last_position_lon: 121.4737,
    speed: 22.3,
    course: 250,
    status: "In Transit",
    type: "Container",
  },
];


function moveVessels() {
  mockVessels = mockVessels.map(v => ({
    ...v,
    last_position_lat: v.last_position_lat + (Math.random() - 0.5) * 0.05,
    last_position_lon: v.last_position_lon + (Math.random() - 0.5) * 0.05,
    course: (v.course + Math.random() * 10) % 360,
  }));
}

export async function fetchDashboardStats() {
  try {
    const res = await fetch("http://127.0.0.1:8000/api/vessels/");
    const data = await res.json();

    return {
      totalVessels: data.count || data.vessels?.length || 0,
      activeVoyages: 342,
      ports: 89,
      events: 156,
      recentVoyages: data.vessels || [],
    };
  } catch (err) {
    console.error("Dashboard API error:", err);

    // fallback demo data
    return {
      totalVessels: mockVessels.length,
      activeVoyages: 2,
      ports: 5,
      events: 3,
      recentVoyages: mockVessels,
    };
  }
}

// ===========================================================
// ✅ LIVE VESSELS (USED BY MAP)
// ===========================================================
export async function fetchLiveVessels() {
  try {
    const res = await fetch("http://127.0.0.1:8000/api/vessels/");
    if (!res.ok) throw new Error("API failed");
    return await res.json();
  } catch (err) {
    console.warn("Using moving mock vessels");
    moveVessels();
    return { vessels: mockVessels };
  }
}
